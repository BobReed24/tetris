# tetris

An almost complete tetris.

## dev

To start a figwheel development server, do:

    clojure -M:server

To build a static index.html, do

    clojure -M:app > index.html

